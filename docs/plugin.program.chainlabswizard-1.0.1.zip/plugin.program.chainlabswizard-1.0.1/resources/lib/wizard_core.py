import xbmcgui, xbmcaddon, xbmc
import os, shutil, zipfile, tempfile, urllib.request

class WizardCore:
    def __init__(self, name, build_url, version):
        self.name = name
        self.build_url = build_url
        self.version = version
        self.addon = xbmcaddon.Addon()

    def run(self):
        dialog = xbmcgui.Dialog()
        choice = dialog.select(f"{self.name} Wizard v{self.version}", ["Install Build", "Update Build"])
        if choice in (0, 1):
            self.install()

    def install(self):
        dp = xbmcgui.DialogProgress()
        dp.create(self.name, "Downloading build...")
        temp_dir = tempfile.mkdtemp()
        zip_path = os.path.join(temp_dir, "build.zip")
        urllib.request.urlretrieve(self.build_url, zip_path)
        dp.update(50)
        extract_dir = os.path.join(temp_dir, "extracted")
        with zipfile.ZipFile(zip_path, "r") as zf:
            zf.extractall(extract_dir)
        dp.update(80)
        for root, _, files in os.walk(extract_dir):
            for f in files:
                src = os.path.join(root, f)
                rel = os.path.relpath(src, extract_dir)
                dst = os.path.join(xbmc.translatePath("special://userdata"), rel)
                os.makedirs(os.path.dirname(dst), exist_ok=True)
                shutil.copy2(src, dst)
        dp.close()
        xbmcgui.Dialog().ok("Install", "Build installed successfully!")
