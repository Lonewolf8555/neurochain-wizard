import xbmcaddon
import os

#########################################################
#         Global Variables - DON'T EDIT!!!              #
#########################################################
ADDON_ID    = xbmcaddon.Addon().getAddonInfo('id')
PATH        = xbmcaddon.Addon().getAddonInfo('path')
ART         = os.path.join(PATH, 'resources', 'media')
#########################################################

#########################################################
#        User Edit Variables                            #
#########################################################
# -- Wizard display name --
COLOR1      = '#00AEEF'          # neon‐blue primary
COLOR2      = '#1A1A2E'          # very dark‐blue secondary
ADDONTITLE  = u'[COLOR {0}][B]Neuro[/B][/COLOR][COLOR {1}]ChainLabs[/COLOR]'.format(COLOR1, COLOR2)
BUILDERNAME = 'NeuroChainLabs Wizard'

# Builds list URL (direct download link for your builds.txt)
# Google Drive share → direct download:
# https://drive.google.com/uc?export=download&id=<file-id>
BUILDFILE   = 'https://drive.google.com/uc?export=download&id=1vTXcf2nEfF-ZFcIfUBLmNIQhS-uDBaPm'

# How often to check for updates (0 = every Kodi start)
UPDATECHECK = 0

# Leave these as-is unless you also host APKs, YouTube lists, etc.
APKFILE     = 'http://'
YOUTUBEFILE = 'http://'
ADDONFILE   = 'http://'
ADVANCEDFILE= 'http://'
#########################################################

#########################################################
#        Theming Menu Items                             #
#########################################################
ICONBUILDS    = os.path.join(ART, 'builds.png')
ICONMAINT     = os.path.join(ART, 'maintenance.png')
ICONSPEED     = os.path.join(ART, 'speed.png')
ICONAPK       = os.path.join(ART, 'apkinstaller.png')
ICONADDONS    = os.path.join(ART, 'addoninstaller.png')
ICONYOUTUBE   = os.path.join(ART, 'youtube.png')
ICONSAVE      = os.path.join(ART, 'savedata.png')
ICONTRAKT     = os.path.join(ART, 'keeptrakt.png')
ICONREAL      = os.path.join(ART, 'keepdebrid.png')
ICONLOGIN     = os.path.join(ART, 'keeplogin.png')
ICONCONTACT   = os.path.join(ART, 'information.png')
ICONSETTINGS  = os.path.join(ART, 'settings.png')

HIDESPACERS   = 'No'
SPACER        = '='

# Apply your blue/dark theme to menu text
THEME1 = u'[COLOR {0}][I]([COLOR {0}][B]NeuroChainLabs[/B][/COLOR])[/I][/COLOR] [COLOR {1}]{{}}[/COLOR]'.format(COLOR1, COLOR2)
THEME2 = u'[COLOR {0}]{{}}[/COLOR]'.format(COLOR1)
THEME3 = u'[COLOR {0}]{{}}[/COLOR]'.format(COLOR1)
THEME4 = u'[COLOR {0}]Current Build:[/COLOR] [COLOR {1}]{{}}[/COLOR]'.format(COLOR1, COLOR2)
THEME5 = u'[COLOR {0}]Current Theme:[/COLOR] [COLOR {1}]{{}}[/COLOR]'.format(COLOR1, COLOR2)

HIDECONTACT   = 'No'
CONTACT       = 'Thank you for choosing NeuroChainLabs Wizard.\n\nVisit us at https://neurochainlabs.example.com'
CONTACTICON   = os.path.join(ART, 'qricon.png')
CONTACTFANART = 'http://'
#########################################################

#########################################################
#    Auto-update & Repo installation settings           #
#########################################################
AUTOUPDATE    = 'Yes'
AUTOINSTALL   = 'No'
REPOID        = 'repository.openwizard'
REPOADDONXML  = 'https://'
REPOZIPURL    = 'https://'
#########################################################

#########################################################
#        Notification Window (optional)                 #
#########################################################
ENABLE        = 'Yes'
NOTIFICATION  = 'http://'
HEADERTYPE    = 'Text'
FONTHEADER    = 'Font14'
HEADERMESSAGE = u'[COLOR {0}][B]Neuro[/B][/COLOR][COLOR {1}]ChainLabs[/COLOR]'.format(COLOR1, COLOR2)
HEADERIMAGE   = 'http://'
FONTSETTINGS  = 'Font13'
BACKGROUND    = 'http://'
#########################################################
